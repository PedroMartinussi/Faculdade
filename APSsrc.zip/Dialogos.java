package APS;

public interface Dialogos {
	void dialogarV();
	void dialogarD();
	String getNome();
}
